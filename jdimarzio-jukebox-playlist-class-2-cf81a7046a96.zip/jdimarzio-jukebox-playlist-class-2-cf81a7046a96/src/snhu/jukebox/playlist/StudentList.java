package snhu.jukebox.playlist;

import snhu.student.playlists.*;

import java.util.ArrayList;
import java.util.List;

public class StudentList {

	public StudentList(){
	}

	public List<String> getStudentsNames() {
		ArrayList<String> studentNames = new ArrayList<String>();
		
		String StudentName1 = "TestStudent1Name";
		studentNames.add(StudentName1);
		
		String StudentName2 = "TestStudent2Name";
		studentNames.add(StudentName2);
		
		String BrandonStultz = "Brandon_Stultz";      //Created variable for student 'Brandon Stultz'
		studentNames.add(BrandonStultz);              //Added 'Brandon Stultz' to 'studentNames' array
		                                              //@author Brandon.Stultz
		
		//Adding 'Priscilla Gomes-DaCosta' as a student
		String PriscillaGomesDaCosta = "PriscillaGomesDaCosta";
		studentNames.add(PriscillaGomesDaCosta);
		
		//Add student 'Jean Petit'
		String JeanPetit = "Jean Petit";
		studentNames.add(JeanPetit);
		                                                   
		//Add student 'Riley Snowe'
		String RileySnowe = "Riley_Snowe";
		studentNames.add(RileySnowe); 
		
		// Adding Carlos Ramirez to create a new student profile.
		String carlosRamirez = "Carlos Ramirez";
		studentNames.add(carlosRamirez);
		
		//Module 5 Code Assignment
		//Add your name to create a new student profile
		//Use template below and put your name in the areas of 'StudentName'
		//String StudentName3 = "TestStudent3Name";
		//studentNames.add(StudentName3);
		
		return studentNames;
	}

	public Student GetStudentProfile(String student){
		Student emptyStudent = null;
	
		switch(student) {
		   case "TestStudent1_Playlist":
			   TestStudent1_Playlist testStudent1Playlist = new TestStudent1_Playlist();
			   Student TestStudent1 = new Student("TestStudent1", testStudent1Playlist.StudentPlaylist());
			   return TestStudent1;
			   
		   case "TestStudent2_Playlist":
			   TestStudent2_Playlist testStudent2Playlist = new TestStudent2_Playlist();
			   Student TestStudent2 = new Student("TestStudent2", testStudent2Playlist.StudentPlaylist());
			   return TestStudent2;
			   
			 //Add Priscilla Gomes-DaCosta student profile    
		   case "PriscillaGomesDaCosta_Playlist":
			   PriscillaGomesDaCosta_Playlist PriscillaGomesDaCostaPlaylist = new PriscillaGomesDaCosta_Playlist();
			   Student PriscillaGomesDaCosta = new Student("Priscilla Gomes-DaCosta", PriscillaGomesDaCostaPlaylist.StudentPlaylist());
			   return PriscillaGomesDaCosta; 
			   
		   //Add Jean Petit student profile
		   case "JeanPetit_Playlist":
			   JeanPetit_Playlist jeanPetitPlaylist = new JeanPetit_Playlist();
			   Student JeanPetit = new Student("Jean Petit", jeanPetitPlaylist.StudentPlaylist());
			   return JeanPetit;
			   
		   //Module 6 Code Assignment - Add your own case statement for your profile. Use the above case statements as a template.

		}
		return emptyStudent;
	}
}
