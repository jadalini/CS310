package snhu.jukebox.playlist.tests;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.Test;
import music.artist.*;
import snhu.jukebox.playlist.Song;

public class JukeboxTest {

	@Test
	public void testGetBeatlesAlbumSize() throws NoSuchFieldException, SecurityException {
		 TheBeatles theBeatlesBand = new TheBeatles();
		 ArrayList<Song> beatlesTracks = new ArrayList<Song>();
		 beatlesTracks = theBeatlesBand.getBeatlesSongs();
		 assertEquals(2, beatlesTracks.size());
	}
	
	@Test
	public void testGetImagineDragonsAlbumSize() throws NoSuchFieldException, SecurityException {
		 ImagineDragons imagineDragons = new ImagineDragons();
		 ArrayList<Song> imagineDragonsTracks = new ArrayList<Song>();
		 imagineDragonsTracks = imagineDragons.getImagineDragonsSongs();
		 assertEquals(3, imagineDragonsTracks.size());
	}
	
	@Test
	public void testGetAdelesAlbumSize() throws NoSuchFieldException, SecurityException {
		 Adele adele = new Adele();
		 ArrayList<Song> adelesTracks = new ArrayList<Song>();
		 adelesTracks = adele.getAdelesSongs();
		 assertEquals(3, adelesTracks.size());
	}
	
	@Test
	public void testGetIssuesAlbumSize() throws NoSuchFieldException, SecurityException {
		Issues issues = new Issues();                                                        //Generates new Instance of 'Issues' Class
		ArrayList<Song> issuesTracks = new ArrayList<Song>();                                //Creates new array of 'songs' called 'issuesTracks'
		issuesTracks = issues.getIssuesSongs();                                              //Sets the array equal to the 'issues' class 'get' method'
		assertEquals(3, issuesTracks.size());                                                //Tests whether there are in fact three songs in issues track
	}                                                                                        //@author Brandon.Stultz 2021-07-27
	
	@Test
	public void testGetArcticMonkeysAlbumSize() throws NoSuchFieldException, SecurityException {
		ArcticMonkeys arcticMonkeys = new ArcticMonkeys();                                   //Generates new Instance of 'Issues' Class
		ArrayList<Song> arcticMonkeysTracks = new ArrayList<Song>();                         //Creates new array of 'songs' called 'arcticMonkeysTracks'
		arcticMonkeysTracks = arcticMonkeys.getArcticMonkeysSongs();                         //Populates the array equal to the 'ArcticMonkeys' class 'get' method'
		assertEquals(2, arcticMonkeysTracks.size());                                         //Tests whether there are in fact two songs in issues track
	}                                                                                        //@author Brandon.Stultz 2021-07-27
	
}
