package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

/*
Created a new playlist class that contains all of Carlos Ramirez
songs of choice.
*/

public class CarlosRamirez_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	
	ArrayList<Song> eminemTracks = new ArrayList<Song>(); // Create a list to hold eminem's songs.
    Eminem eminemArtist = new Eminem();					  // Create instance of the Eminem class.
    eminemTracks = eminemArtist.getEminemSongs();         // Added all the song from the Emenim class into the eminemTracks list.
	
    // Added two Eminem songs to the playable song Playlist
	playlist.add(eminemTracks.get(0));
	playlist.add(eminemTracks.get(1));
	
	ArrayList<Song> postMaloneTracks = new ArrayList<Song>(); // Create a list to hold Post Malone's songs.
    PostMalone postMaloneArtist = new PostMalone(); 	 // Create instance of the Post Malone class.	
    postMaloneTracks = postMaloneArtist.getPostMaloneSongs(); // Added all the song from the Post Malone class into the postMaloneTracks list.
	
    // Added three Post Malone songs to the playable song Playlist
	playlist.add(postMaloneTracks.get(0));
	playlist.add(postMaloneTracks.get(1));
	playlist.add(postMaloneTracks.get(2));
	
	ArrayList<Song> halseyTracks = new ArrayList<Song>(); // Create a list to hold Halsey's songs.
    Halsey halseyArtist = new Halsey(); 				 // Create instance of the Halsey class.
    halseyTracks = halseyArtist.getHalseySongs();		 // Added all the song from the Halsey class into the halseyTracks list.
    
    // Added three Halsey songs to the playable song Playlist
	playlist.add(halseyTracks.get(0));
	playlist.add(halseyTracks.get(1));
	playlist.add(halseyTracks.get(2));
	
	
	// Returns the entire playable song list
    return playlist;
	}
}
