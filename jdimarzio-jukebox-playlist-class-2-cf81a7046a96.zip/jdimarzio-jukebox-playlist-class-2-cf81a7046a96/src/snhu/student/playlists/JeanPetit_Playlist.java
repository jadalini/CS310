package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class JeanPetit_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	//Adding tracks from Donnie McClurkin
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();
	ArrayList<Song> donnieMcClurkinTracks = new ArrayList<Song>();
	DonnieMcClurkin donnieMcClurkinBand = new DonnieMcClurkin();
	
	donnieMcClurkinTracks = donnieMcClurkinBand.getDonnieMcClurkinSongs();
	
	playlist.add(donnieMcClurkinTracks.get(0));
	playlist.add(donnieMcClurkinTracks.get(1));
	
	//Add tracks from Ray Charles
    RayCharles rayCharlesBand = new RayCharles();
	ArrayList<Song> rayCharlesTracks = new ArrayList<Song>();
	rayCharlesTracks = rayCharlesBand.getRayCharlesSongs();
	
	playlist.add(rayCharlesTracks.get(0));
	playlist.add(rayCharlesTracks.get(1));
	playlist.add(rayCharlesTracks.get(2));
	
	//Add tracks from The Beatles
	TheBeatles theBeatlesBand = new TheBeatles();
	ArrayList<Song> theBeatlesTracks = new ArrayList<Song>();
	theBeatlesTracks = theBeatlesBand.getBeatlesSongs();
	
	playlist.add(theBeatlesTracks.get(1));
	
    return playlist;
	}
}