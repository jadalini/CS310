package snhu.student.playlists;

import snhu.jukebox.playlist.PlayableSong;
import snhu.jukebox.playlist.Song;
import music.artist.*;
import java.util.ArrayList;
import java.util.LinkedList;

public class TestStudent1_Playlist {
    
	public LinkedList<PlayableSong> StudentPlaylist(){
	
	LinkedList<PlayableSong> playlist = new LinkedList<PlayableSong>();

	//The Beatles song playlist
	TheBeatles theBeatlesBand = new TheBeatles();
	ArrayList<Song> beatlesTracks = new ArrayList<Song>();
    beatlesTracks = theBeatlesBand.getBeatlesSongs();
	
	playlist.add(beatlesTracks.get(0));
	playlist.add(beatlesTracks.get(1));
	
	//Halsey song playlist
    Halsey halseyBand = new Halsey();
	ArrayList<Song> halseyTracks = new ArrayList<Song>();
    halseyTracks = halseyBand.getHalseySongs();
	
	playlist.add(halseyTracks.get(0));
	playlist.add(halseyTracks.get(1));
	playlist.add(halseyTracks.get(2));
	
    return playlist;
	}
}
